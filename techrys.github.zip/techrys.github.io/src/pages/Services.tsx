import React from 'react';
import { motion } from 'framer-motion';
import { Link } from 'react-router-dom';
import { ArrowLeft, Laptop, Home, Code, Shield, Database, Cloud } from 'lucide-react';

const Services = () => {
  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1
      }
    }
  };

  const itemVariants = {
    hidden: { opacity: 0, y: 20 },
    visible: { opacity: 1, y: 0 }
  };

  return (
    <div className="min-h-screen bg-gray-900 pt-20">
      <div className="max-w-7xl mx-auto px-4 py-12">
        <div className="flex items-center mb-8">
          <Link to="/" className="text-gray-400 hover:text-blue-400 transition-colors flex items-center">
            <ArrowLeft className="mr-2" size={20} />
            Back to Home
          </Link>
        </div>

        <motion.h1
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          className="text-4xl font-bold mb-12 text-center bg-gradient-to-r from-blue-400 to-cyan-400 bg-clip-text text-transparent"
        >
          Services & Rates
        </motion.h1>

        <motion.div
          variants={containerVariants}
          initial="hidden"
          animate="visible"
          className="grid md:grid-cols-2 lg:grid-cols-3 gap-6"
        >
          {/* Remote Support */}
          <motion.div variants={itemVariants} className="col-span-full lg:col-span-2">
            <div className="glass-card p-8 rounded-xl hover:border-blue-500/50 transition-all duration-300">
              <div className="flex items-center mb-6">
                <Laptop className="text-blue-400 w-8 h-8 mr-4" />
                <h3 className="text-2xl font-bold text-blue-400">Remote Support</h3>
              </div>
              <p className="text-gray-300 mb-6">Fast and professional remote tech support available 24/7.</p>
              <div className="grid md:grid-cols-2 gap-4 mb-6">
                <div>
                  <h4 className="font-semibold mb-2">Services Include:</h4>
                  <ul className="space-y-2">
                    <li className="flex items-center"><span className="w-2 h-2 bg-green-400 rounded-full mr-2" />Virus Removal</li>
                    <li className="flex items-center"><span className="w-2 h-2 bg-green-400 rounded-full mr-2" />Software Issues</li>
                    <li className="flex items-center"><span className="w-2 h-2 bg-green-400 rounded-full mr-2" />System Optimization</li>
                  </ul>
                </div>
                <div>
                  <h4 className="font-semibold mb-2">Additional Services:</h4>
                  <ul className="space-y-2">
                    <li className="flex items-center"><span className="w-2 h-2 bg-green-400 rounded-full mr-2" />Driver Updates</li>
                    <li className="flex items-center"><span className="w-2 h-2 bg-green-400 rounded-full mr-2" />Security Setup</li>
                    <li className="flex items-center"><span className="w-2 h-2 bg-green-400 rounded-full mr-2" />Data Recovery</li>
                  </ul>
                </div>
              </div>
              <div className="flex justify-between items-center">
                <span className="text-blue-400 font-bold">$50/hour</span>
                <Link to="/digital-services" className="text-blue-400 hover:text-blue-300">
                  View Digital Services →
                </Link>
              </div>
            </div>
          </motion.div>

          {/* On-Site Support */}
          <motion.div variants={itemVariants}>
            <div className="glass-card p-8 rounded-xl hover:border-blue-500/50 transition-all duration-300 h-full">
              <div className="flex items-center mb-6">
                <Home className="text-blue-400 w-8 h-8 mr-4" />
                <h3 className="text-2xl font-bold text-blue-400">On-Site Support</h3>
              </div>
              <p className="text-gray-300 mb-6">Professional tech support at your location.</p>
              <ul className="space-y-2 mb-6">
                <li className="flex items-center"><span className="w-2 h-2 bg-green-400 rounded-full mr-2" />Home & Office Visits</li>
                <li className="flex items-center"><span className="w-2 h-2 bg-green-400 rounded-full mr-2" />Hardware Installation</li>
                <li className="flex items-center"><span className="w-2 h-2 bg-green-400 rounded-full mr-2" />Network Setup</li>
                <li className="flex items-center"><span className="w-2 h-2 bg-green-400 rounded-full mr-2" />PC Building</li>
              </ul>
              <span className="text-blue-400 font-bold">$75/hour + travel</span>
            </div>
          </motion.div>

          {/* Additional Services */}
          {[
            {
              icon: <Code className="text-blue-400 w-8 h-8 mr-4" />,
              title: 'Web Development',
              description: 'Custom websites and web applications.',
              price: 'Starting at $500'
            },
            {
              icon: <Shield className="text-blue-400 w-8 h-8 mr-4" />,
              title: 'Security Services',
              description: 'Protect your digital assets and data.',
              price: 'Starting at $300'
            },
            {
              icon: <Database className="text-blue-400 w-8 h-8 mr-4" />,
              title: 'Data Services',
              description: 'Database design and data recovery.',
              price: 'Starting at $400'
            },
            {
              icon: <Cloud className="text-blue-400 w-8 h-8 mr-4" />,
              title: 'Cloud Solutions',
              description: 'Cloud infrastructure and deployment.',
              price: 'Starting at $600'
            }
          ].map((service, index) => (
            <motion.div key={index} variants={itemVariants}>
              <div className="glass-card p-8 rounded-xl hover:border-blue-500/50 transition-all duration-300 h-full">
                <div className="flex items-center mb-6">
                  {service.icon}
                  <h3 className="text-2xl font-bold text-blue-400">{service.title}</h3>
                </div>
                <p className="text-gray-300 mb-6">{service.description}</p>
                <span className="text-blue-400 font-bold">{service.price}</span>
              </div>
            </motion.div>
          ))}
        </motion.div>
      </div>
    </div>
  );
};

export default Services;